Morgan Yost
MATH 502
Homework 2
Nonlinear Pendulum Problem

RUN:
To see all requested plots simply type nonlinPendulum into the commandline
